/**
 * Vercel Serverless Function
 * ChinaGCC Dashboard → /api/github-snapshot → GitHub 私有仓库 wpuu/ChinaGCC
 * GITHUB_TOKEN 只允许服务端读取，浏览器端禁止保存 Token。
 */

type NodeRes = {
  status: (code: number) => NodeRes;
  setHeader: (k: string, v: string) => void;
  json: (body: unknown) => void;
  end: () => void;
};

type NodeReq = {
  method?: string;
};

const REPO = "wpuu/ChinaGCC";
const PATH = "data/current.json";

export default async function handler(req: NodeReq, res: NodeRes) {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Content-Type", "application/json; charset=utf-8");

  if (req.method && req.method !== "GET") {
    res.status(405).json({ ok: false, error: "仅支持 GET" });
    return;
  }

  const token = process.env.GITHUB_TOKEN;
  if (!token) {
    res.status(204).end();
    return;
  }

  try {
    const url = `https://api.github.com/repos/${REPO}/contents/${PATH}`;
    const gh = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "ChinaGCC-Dashboard",
      },
    });

    if (!gh.ok) {
      const text = await gh.text();
      res.status(gh.status).json({
        ok: false,
        error: `GitHub 读取失败（${gh.status}）。请确认仓库 wpuu/ChinaGCC 与路径 ${PATH}。 ${text.slice(0, 200)}`,
      });
      return;
    }

    const payload = (await gh.json()) as {
      content?: string;
      encoding?: string;
      sha?: string;
      path?: string;
      download_url?: string;
    };

    let raw = "";
    if (payload.encoding === "base64" && payload.content) {
      raw = Buffer.from(payload.content.replace(/\n/g, ""), "base64").toString("utf-8");
    } else if (payload.download_url) {
      const fileRes = await fetch(payload.download_url, {
        headers: {
          Authorization: `Bearer ${token}`,
          "User-Agent": "ChinaGCC-Dashboard",
        },
      });
      raw = await fileRes.text();
    } else {
      res.status(502).json({ ok: false, error: "GitHub 返回内容无法解码。" });
      return;
    }

    let data: unknown;
    try {
      data = JSON.parse(raw);
    } catch {
      res.status(502).json({ ok: false, error: `${PATH} 不是合法 JSON。` });
      return;
    }

    res.status(200).json({
      ok: true,
      data,
      lastSynced: new Date().toISOString(),
      sha: payload.sha,
      path: payload.path ?? PATH,
      repo: REPO,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "未知错误";
    res.status(500).json({ ok: false, error: `同步异常：${msg}` });
  }
}
