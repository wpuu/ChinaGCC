import type { Risk, Sku } from "../types";

export function riskValue(risk: Risk): number {
  const p = Number(risk.probability) || 0;
  const i = Number(risk.impact) || 0;
  return p * i;
}

export function riskLevel(value: number): "low" | "mid" | "high" | "severe" {
  if (value >= 16) return "severe";
  if (value >= 11) return "high";
  if (value >= 6) return "mid";
  return "low";
}

export function riskLevelLabel(value: number): string {
  const lv = riskLevel(value);
  if (lv === "severe") return "严重";
  if (lv === "high") return "高";
  if (lv === "mid") return "中";
  return "低";
}

export function getTopRisks(sku: Sku, n = 5): Risk[] {
  const list = sku.risks ?? [];
  return [...list].sort((a, b) => riskValue(b) - riskValue(a)).slice(0, n);
}

export function getHardStops(sku: Sku): Risk[] {
  return (sku.risks ?? []).filter((r) => r.isHardStop);
}

export function getSevereOpenRisks(sku: Sku): Risk[] {
  return (sku.risks ?? []).filter((r) => {
    const v = riskValue(r);
    if (v < 16) return false;
    return r.residualRisk >= 16 || !r.canMitigate;
  });
}
