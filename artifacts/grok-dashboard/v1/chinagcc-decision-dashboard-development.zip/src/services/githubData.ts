import type { ChinaGCCData } from "../types";
import { isChinaGCCData } from "./dataSource";

export interface GithubSnapshotResponse {
  ok: boolean;
  reason?: string;
  data?: ChinaGCCData;
  lastSynced?: string;
  sha?: string;
  path?: string;
}

export async function fetchGithubSnapshot(): Promise<GithubSnapshotResponse> {
  try {
    const res = await fetch("/api/github-snapshot", {
      method: "GET",
      cache: "no-store",
      headers: { Accept: "application/json" },
    });

    if (res.status === 204) {
      return { ok: false, reason: "未配置 GitHub Token，已跳过远程同步。" };
    }

    if (!res.ok) {
      let reason = `GitHub 同步失败（HTTP ${res.status}）`;
      try {
        const body = (await res.json()) as { error?: string };
        if (body?.error) reason = body.error;
      } catch {
        /* ignore */
      }
      return { ok: false, reason };
    }

    const body = (await res.json()) as GithubSnapshotResponse;
    if (!body?.data || !isChinaGCCData(body.data)) {
      return { ok: false, reason: "GitHub 返回数据格式无效。" };
    }
    return {
      ok: true,
      data: body.data,
      lastSynced: body.lastSynced ?? new Date().toISOString(),
      sha: body.sha,
      path: body.path,
    };
  } catch {
    return { ok: false, reason: "无法连接同步接口，已使用本地数据。" };
  }
}
